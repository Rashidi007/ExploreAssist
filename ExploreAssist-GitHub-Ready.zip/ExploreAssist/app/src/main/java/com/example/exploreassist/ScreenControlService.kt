package com.example.exploreassist

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import android.provider.Settings

class ScreenControlService : AccessibilityService() {
    private var windowManager: WindowManager? = null
    private var floatingView: LinearLayout? = null
    @Volatile private var instagramIsForeground = false

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        if (Settings.canDrawOverlays(this)) showFloatingPanel()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val packageName = event.packageName?.toString() ?: return
        instagramIsForeground = packageName == INSTAGRAM_PACKAGE
    }

    override fun onInterrupt() {
        instagramIsForeground = false
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        removeFloatingPanel()
        instagramIsForeground = false
        if (instance === this) instance = null
        return super.onUnbind(intent)
    }

    fun showFloatingPanel() {
        if (!Settings.canDrawOverlays(this) || floatingView != null) return
        val density = resources.displayMetrics.density
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((10 * density).toInt(), (8 * density).toInt(), (10 * density).toInt(), (8 * density).toInt())
            background = GradientDrawable().apply {
                setColor(0xEE202124.toInt())
                cornerRadius = 14f * density
                setStroke((1 * density).toInt(), 0xFF777777.toInt())
            }
        }

        val heading = TextView(this).apply {
            text = "Explore Assist · دستی"
            textSize = 13f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, (5 * density).toInt())
        }
        panel.addView(heading)

        val likeButton = Button(this).apply {
            text = "♥ دابل‌تپ یک‌باره"
            isAllCaps = false
            textSize = 12f
            setOnClickListener { doubleTapOnce() }
        }
        panel.addView(likeButton)

        val scrollButton = Button(this).apply {
            text = "↓ اسکرول یک‌باره"
            isAllCaps = false
            textSize = 12f
            setOnClickListener { scrollOnce() }
        }
        panel.addView(scrollButton)

        val closeButton = Button(this).apply {
            text = "بستن پنل"
            isAllCaps = false
            textSize = 11f
            setOnClickListener { removeFloatingPanel() }
        }
        panel.addView(closeButton)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = (10 * density).toInt()
            y = (130 * density).toInt()
        }

        try {
            windowManager?.addView(panel, params)
            floatingView = panel
        } catch (_: Exception) {
            Toast.makeText(this, "نمایش پنل ممکن نشد؛ مجوز پنجره شناور را بررسی کن", Toast.LENGTH_LONG).show()
        }
    }

    private fun removeFloatingPanel() {
        val view = floatingView ?: return
        try {
            windowManager?.removeView(view)
        } catch (_: Exception) {
            // The view may already have been detached by Android.
        }
        floatingView = null
    }

    private fun ensureInstagramForeground(): Boolean {
        if (!instagramIsForeground) {
            Toast.makeText(this, "اول اینستاگرام را باز کن و پست را تمام‌صفحه نمایش بده", Toast.LENGTH_LONG).show()
            return false
        }
        return true
    }

    private fun doubleTapOnce() {
        if (!ensureInstagramForeground()) return
        val width = resources.displayMetrics.widthPixels.toFloat()
        val height = resources.displayMetrics.heightPixels.toFloat()
        val x = width * 0.5f
        val y = height * 0.48f

        val firstPath = Path().apply { moveTo(x, y) }
        val secondPath = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(firstPath, 0, 65))
            .addStroke(GestureDescription.StrokeDescription(secondPath, 135, 65))
            .build()

        val accepted = dispatchGesture(gesture, null, null)
        if (!accepted) Toast.makeText(this, "ارسال لمس ناموفق بود", Toast.LENGTH_SHORT).show()
    }

    private fun scrollOnce() {
        if (!ensureInstagramForeground()) return
        val width = resources.displayMetrics.widthPixels.toFloat()
        val height = resources.displayMetrics.heightPixels.toFloat()
        val x = width * 0.5f
        val path = Path().apply {
            moveTo(x, height * 0.80f)
            lineTo(x, height * 0.32f)
        }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 380))
            .build()

        val accepted = dispatchGesture(gesture, null, null)
        if (!accepted) Toast.makeText(this, "ارسال اسکرول ناموفق بود", Toast.LENGTH_SHORT).show()
    }

    companion object {
        private const val INSTAGRAM_PACKAGE = "com.instagram.android"
        @Volatile var instance: ScreenControlService? = null
            private set
    }
}

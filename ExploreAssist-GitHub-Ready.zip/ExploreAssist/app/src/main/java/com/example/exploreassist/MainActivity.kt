package com.example.exploreassist

import android.app.Activity
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var statusText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
        if (Settings.canDrawOverlays(this)) {
            ScreenControlService.instance?.showFloatingPanel()
        }
    }

    private fun buildScreen() {
        val density = resources.displayMetrics.density
        val pad = (20 * density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
            gravity = Gravity.TOP
        }

        val title = TextView(this).apply {
            text = "Explore Assist"
            textSize = 26f
            setTextColor(0xFF171717.toInt())
        }
        root.addView(title, matchWrap())

        val intro = TextView(this).apply {
            text = "کنترل‌گر دستی اینستاگرام\nهر دکمه فقط یک فرمان را با درخواست مستقیم شما اجرا می‌کند. هیچ چرخه یا لایک خودکاری در پس‌زمینه وجود ندارد."
            textSize = 16f
            setTextColor(0xFF444444.toInt())
            setPadding(0, (12 * density).toInt(), 0, (18 * density).toInt())
        }
        root.addView(intro, matchWrap())

        statusText = TextView(this).apply {
            textSize = 14f
            setTextColor(0xFF333333.toInt())
            setPadding(0, 0, 0, (14 * density).toInt())
        }
        root.addView(statusText, matchWrap())

        root.addView(actionButton("۱) اجازه نمایش پنل شناور") {
            if (!Settings.canDrawOverlays(this)) {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
                startActivity(intent)
            } else {
                Toast.makeText(this, "اجازه پنل از قبل فعال است", Toast.LENGTH_SHORT).show()
            }
        })

        root.addView(actionButton("۲) فعال‌کردن سرویس دسترس‌پذیری") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })

        root.addView(actionButton("نمایش دوباره پنل شناور") {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "ابتدا اجازه نمایش روی برنامه‌های دیگر را بده", Toast.LENGTH_LONG).show()
            } else if (ScreenControlService.instance == null) {
                Toast.makeText(this, "ابتدا سرویس دسترس‌پذیری را فعال کن", Toast.LENGTH_LONG).show()
            } else {
                ScreenControlService.instance?.showFloatingPanel()
            }
        })

        root.addView(actionButton("بازکردن اینستاگرام") {
            val launch = packageManager.getLaunchIntentForPackage("com.instagram.android")
            if (launch != null) startActivity(launch)
            else Toast.makeText(this, "اینستاگرام روی گوشی پیدا نشد", Toast.LENGTH_LONG).show()
        })

        val footer = TextView(this).apply {
            text = "روش استفاده: اینستاگرام را باز کن و یک پست/ریل تمام‌صفحه از Explore نمایش بده. پنل شناور را برای یک دابل‌تپ یا یک اسکرول جداگانه به کار ببر."
            textSize = 14f
            setTextColor(0xFF555555.toInt())
            setPadding(0, (20 * density).toInt(), 0, 0)
        }
        root.addView(footer, matchWrap())

        setContentView(root)
        updateStatus()
    }

    private fun actionButton(label: String, action: () -> Unit): Button = Button(this).apply {
        text = label
        isAllCaps = false
        setOnClickListener { action() }
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply {
            bottomMargin = (8 * resources.displayMetrics.density).toInt()
        }
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    )

    private fun updateStatus() {
        if (!::statusText.isInitialized) return
        val overlay = Settings.canDrawOverlays(this)
        val accessibility = isAccessibilityServiceEnabled(this, ScreenControlService::class.java)
        statusText.text = "وضعیت مجوزها:\nپنل شناور: ${if (overlay) "فعال" else "نیازمند اجازه"}\nدسترس‌پذیری: ${if (accessibility) "فعال" else "غیرفعال"}"
    }

    private fun isAccessibilityServiceEnabled(context: Context, serviceClass: Class<*>): Boolean {
        val expected = ComponentName(context, serviceClass).flattenToString()
        val enabled = Settings.Secure.getString(
            context.contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return enabled.split(':').any { it.equals(expected, ignoreCase = true) }
    }
}
